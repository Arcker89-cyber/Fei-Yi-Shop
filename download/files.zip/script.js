/**
 * Fei Yi Shop - Bundled Version
 * รวม config, data, cart, ui ไว้ในไฟล์เดียว
 * ง่ายต่อการใช้งานและพัฒนาต่อ
 */

(function() {
  'use strict';

  // ============================================================
  // CONFIG - ค่าคงที่และการตั้งค่า
  // ============================================================
  const CONFIG = {
    STORE_NAME: 'Fei Yi Shop',
    STORE_SLOGAN: 'เครื่องมือดี คู่ช่างไทย',
    LINE_ID: '@feiyi',
    PHONE: '089-123-4567',
    CART_STORAGE_KEY: 'feiyi_cart_v2',
    LINE_MSG_URL: 'https://line.me/R/msg/text/',
    CURRENCY: '฿',
    LOCALE: 'th-TH'
  };

  const CATEGORIES = {
    electric: 'เครื่องมือไฟฟ้า',
    auto: 'เครื่องมือซ่อมรถ',
    hand: 'เครื่องมือช่างทั่วไป'
  };

  // ============================================================
  // PRODUCTS DATA - ข้อมูลสินค้า
  // ============================================================
  const PRODUCTS = [
    {
      id: "drill48",
      title: "สว่านไฟฟ้าไร้สาย 48V",
      price: 1290,
      img: "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=800&h=600&fit=crop",
      category: "electric",
      desc: "สว่านไร้สายพลังสูง เหมาะงานหนัก แบตอึด ทนทาน",
      stock: 25,
      specs: {
        voltage: "48V",
        battery: "Li-ion 2000mAh",
        weight: "1.2 kg"
      }
    },
    {
      id: "airImpact",
      title: "บล๊อกลมแรงบิดสูง",
      price: 2590,
      img: "https://images.unsplash.com/photo-1426927308491-6380b6a9936f?w=800&h=600&fit=crop",
      category: "auto",
      desc: "บล๊อกลมสำหรับงานอู่รถ มั่นใจแรงบิดสูง ประหยัดเวลา",
      stock: 12,
      specs: {
        torque: "1200 Nm",
        airPressure: "90 PSI",
        weight: "2.5 kg"
      }
    },
    {
      id: "plier",
      title: "คีมปากจิ้งจกเหล็กกล้า",
      price: 190,
      img: "https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?w=800&h=600&fit=crop",
      category: "hand",
      desc: "คีมปากจิ้งจก ออกแบบจับถนัด ทนทาน ไม่ลื่น",
      stock: 100,
      specs: {
        material: "Chrome Vanadium Steel",
        length: "6 นิ้ว"
      }
    },
    {
      id: "wrenchSet",
      title: "ประแจหกเหลี่ยมชุด 12 ตัว",
      price: 890,
      img: "https://images.unsplash.com/photo-1581147036324-c17ac41f3e6b?w=800&h=600&fit=crop",
      category: "hand",
      desc: "ชุดประแจครบทุกขนาด เหมาะสำหรับงานบ้านและอู่ช่าง",
      stock: 45,
      specs: {
        pieces: 12,
        sizes: "1.5mm - 10mm",
        material: "CR-V Steel"
      }
    },
    {
      id: "grinder4",
      title: "ลูกหมู (เครื่องเจียร) 4 นิ้ว",
      price: 450,
      img: "https://images.unsplash.com/photo-1572981779307-38b8cabb2407?w=800&h=600&fit=crop",
      category: "electric",
      desc: "เครื่องเจียร 4 นิ้วกำลังดี ใช้งานต่อเนื่อง แข็งแรง",
      stock: 30,
      specs: {
        discSize: "4 นิ้ว (100mm)",
        power: "850W",
        rpm: "11000"
      }
    }
  ];

  // ============================================================
  // PRODUCT SERVICE - จัดการข้อมูลสินค้า
  // ============================================================
  const ProductService = {
    getById(id) {
      return PRODUCTS.find(p => p.id === id) || null;
    },
    getByCategory(category) {
      return PRODUCTS.filter(p => p.category === category);
    },
    getAll() {
      return [...PRODUCTS];
    },
    search(keyword) {
      const lowerKeyword = keyword.toLowerCase();
      return PRODUCTS.filter(p => 
        p.title.toLowerCase().includes(lowerKeyword) ||
        p.desc.toLowerCase().includes(lowerKeyword)
      );
    }
  };

  // ============================================================
  // CART MANAGER - จัดการตะกร้า
  // ============================================================
  const Cart = {
    listeners: [],

    load() {
      const raw = localStorage.getItem(CONFIG.CART_STORAGE_KEY);
      if (!raw) return [];
      try { return JSON.parse(raw); } 
      catch (e) { return []; }
    },

    save(cart) {
      localStorage.setItem(CONFIG.CART_STORAGE_KEY, JSON.stringify(cart));
      this.notifyListeners();
    },

    clear() {
      localStorage.removeItem(CONFIG.CART_STORAGE_KEY);
      this.notifyListeners();
    },

    addItem(productId, qty = 1) {
      const product = ProductService.getById(productId);
      if (!product) return false;

      const cart = this.load();
      const existingItem = cart.find(item => item.id === productId);

      if (existingItem) {
        existingItem.qty += qty;
      } else {
        cart.push({ id: productId, qty });
      }

      this.save(cart);
      return true;
    },

    removeItem(productId) {
      let cart = this.load();
      cart = cart.filter(item => item.id !== productId);
      this.save(cart);
    },

    updateQuantity(productId, qty) {
      const cart = this.load();
      const item = cart.find(i => i.id === productId);
      
      if (item) {
        if (qty <= 0) {
          this.removeItem(productId);
        } else {
          item.qty = qty;
          this.save(cart);
        }
      }
    },

    getTotalItems() {
      return this.load().reduce((sum, item) => sum + item.qty, 0);
    },

    getTotalPrice() {
      return this.load().reduce((sum, item) => {
        const product = ProductService.getById(item.id);
        return sum + (product ? product.price * item.qty : 0);
      }, 0);
    },

    getCartDetails() {
      const cart = this.load();
      return cart.map(item => {
        const product = ProductService.getById(item.id);
        return {
          ...item,
          product,
          subtotal: product ? product.price * item.qty : 0
        };
      }).filter(item => item.product !== null);
    },

    isEmpty() {
      return this.load().length === 0;
    },

    subscribe(callback) {
      this.listeners.push(callback);
    },

    notifyListeners() {
      const cartData = {
        items: this.getCartDetails(),
        totalItems: this.getTotalItems(),
        totalPrice: this.getTotalPrice()
      };
      this.listeners.forEach(cb => cb(cartData));
    },

    generateOrderSummary() {
      const cartDetails = this.getCartDetails();
      if (cartDetails.length === 0) return null;

      const lines = cartDetails.map(item => 
        `${item.product.title} x${item.qty} = ${CONFIG.CURRENCY}${item.subtotal.toLocaleString(CONFIG.LOCALE)}`
      );

      const total = this.getTotalPrice();
      
      return {
        text: `สั่งซื้อจาก ${CONFIG.STORE_NAME}:\n${lines.join('\n')}\nรวม ${total.toLocaleString(CONFIG.LOCALE)} บาท\nLINE: ${CONFIG.LINE_ID}`,
        total,
        items: cartDetails
      };
    },

    getCheckoutLineUrl() {
      const summary = this.generateOrderSummary();
      if (!summary) return null;
      
      const encoded = encodeURIComponent(summary.text);
      return `${CONFIG.LINE_MSG_URL}?${encoded}`;
    }
  };

  // ============================================================
  // UI HELPERS
  // ============================================================
  const UIHelpers = {
    formatPrice(price) {
      return `${CONFIG.CURRENCY}${price.toLocaleString(CONFIG.LOCALE)}`;
    }
  };

  function generateSingleProductLineUrl(productId, qty = 1) {
    const product = ProductService.getById(productId);
    if (!product) return null;

    const msg = `ผมต้องการสั่งซื้อ: ${product.title} จำนวน ${qty} ชิ้น (${CONFIG.STORE_NAME})`;
    const encoded = encodeURIComponent(msg);
    return `${CONFIG.LINE_MSG_URL}?${encoded}`;
  }

  // ============================================================
  // PRODUCT GRID - แสดงรายการสินค้า
  // ============================================================
  const ProductGrid = {
    render(containerId, products = null) {
      const container = document.getElementById(containerId);
      if (!container) return;

      const productList = products || ProductService.getAll();
      container.innerHTML = productList.map(p => this.renderCard(p)).join('');
      
      this.attachEvents(container);
    },

    renderCard(product) {
      return `
        <div class="product-card" data-product-id="${product.id}">
          <img src="${product.img}" alt="${product.title}" loading="lazy" 
               onerror="this.src='https://via.placeholder.com/800x600?text=No+Image'">
          <h3>${product.title}</h3>
          <div class="price">${UIHelpers.formatPrice(product.price)}</div>
          <div class="card-actions">
            <button class="buy-btn" data-action="add-to-cart" data-id="${product.id}">
              Add to Cart
            </button>
            <button class="line-btn" data-action="line-order" data-id="${product.id}">
              LINE
            </button>
            <a href="product.html?id=${product.id}">
              <button class="line-btn">รายละเอียด</button>
            </a>
          </div>
          <div class="small-muted">${product.desc}</div>
        </div>
      `;
    },

    attachEvents(container) {
      container.querySelectorAll('[data-action="add-to-cart"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.dataset.id;
          Cart.addItem(id, 1);
          CartPanel.open();
        });
      });

      container.querySelectorAll('[data-action="line-order"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.dataset.id;
          const url = generateSingleProductLineUrl(id, 1);
          if (url) window.open(url, '_blank');
        });
      });
    }
  };

  // ============================================================
  // PRODUCT DETAIL - หน้ารายละเอียดสินค้า
  // ============================================================
  const ProductDetail = {
    render(containerId) {
      const container = document.getElementById(containerId);
      if (!container) return;

      const params = new URLSearchParams(location.search);
      const id = params.get('id');
      const product = ProductService.getById(id);

      if (!product) {
        container.innerHTML = `
          <div style="padding:30px; text-align:center;">
            <h2>ไม่พบสินค้า</h2>
            <p>สินค้าที่คุณค้นหาอาจถูกลบหรือไม่มีอยู่ในระบบ</p>
            <a href="index.html" class="btn btn-primary" style="margin-top:16px;">
              กลับหน้าหลัก
            </a>
          </div>
        `;
        return;
      }

      let specsHTML = '';
      if (product.specs) {
        const specItems = Object.entries(product.specs)
          .map(([key, value]) => `<li><strong>${key}:</strong> ${value}</li>`)
          .join('');
        specsHTML = `
          <div class="specs-box">
            <h4>รายละเอียดสินค้า</h4>
            <ul>${specItems}</ul>
          </div>
        `;
      }

      container.innerHTML = `
        <img src="${product.img}" alt="${product.title}"
             onerror="this.src='https://via.placeholder.com/800x600?text=No+Image'">
        <div class="detail-box">
          <span class="category-tag">${CATEGORIES[product.category] || product.category}</span>
          <h1>${product.title}</h1>
          <div class="price">${UIHelpers.formatPrice(product.price)}</div>
          <div class="desc">${product.desc}</div>
          ${specsHTML}
          <div class="stock-info">
            ${product.stock > 0 ? `✓ มีสินค้า (${product.stock} ชิ้น)` : '✗ สินค้าหมด'}
          </div>
          <div class="detail-actions">
            <button id="detail-add" class="buy-btn" ${product.stock <= 0 ? 'disabled' : ''}>
              เพิ่มลงตะกร้า
            </button>
            <button id="detail-line" class="line-btn">
              สั่งผ่าน LINE
            </button>
          </div>
        </div>
      `;

      const addBtn = document.getElementById('detail-add');
      const lineBtn = document.getElementById('detail-line');

      if (addBtn) {
        addBtn.addEventListener('click', () => {
          Cart.addItem(product.id, 1);
          this.showNotification('เพิ่มลงตะกร้าแล้ว ✓');
          CartBadge.update();
        });
      }

      if (lineBtn) {
        lineBtn.addEventListener('click', () => {
          const url = generateSingleProductLineUrl(product.id, 1);
          if (url) window.open(url, '_blank');
        });
      }
    },

    showNotification(message) {
      const toast = document.createElement('div');
      toast.className = 'toast-notification';
      toast.textContent = message;
      document.body.appendChild(toast);

      setTimeout(() => toast.classList.add('show'), 10);
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
      }, 2000);
    }
  };

  // ============================================================
  // CART BADGE - แสดงจำนวนในตะกร้า
  // ============================================================
  const CartBadge = {
    update() {
      const count = Cart.getTotalItems();
      const total = Cart.getTotalPrice();

      document.querySelectorAll('#cart-count, #cart-count-2').forEach(el => {
        el.textContent = count;
      });

      document.querySelectorAll('#cart-total, #cart-total-2').forEach(el => {
        el.textContent = UIHelpers.formatPrice(total);
      });
    }
  };

  // ============================================================
  // CART PANEL - ตะกร้าสินค้า popup
  // ============================================================
  const CartPanel = {
    panelIds: ['cart-panel', 'cart-panel-2'],

    open() {
      this.panelIds.forEach(id => {
        const panel = document.getElementById(id);
        if (panel) panel.classList.remove('hidden');
      });
      this.renderItems();
    },

    close() {
      this.panelIds.forEach(id => {
        const panel = document.getElementById(id);
        if (panel) panel.classList.add('hidden');
      });
    },

    toggle() {
      const panel = document.getElementById('cart-panel') || 
                    document.getElementById('cart-panel-2');
      if (panel) {
        panel.classList.toggle('hidden');
        if (!panel.classList.contains('hidden')) {
          this.renderItems();
        }
      }
    },

    renderItems() {
      const containers = [
        document.getElementById('cart-items'),
        document.getElementById('cart-items-2')
      ].filter(Boolean);

      const cartDetails = Cart.getCartDetails();

      containers.forEach(container => {
        if (cartDetails.length === 0) {
          container.innerHTML = `
            <div class="empty-cart">
              <div style="font-size: 48px; margin-bottom: 12px;">🛒</div>
              <div>ตะกร้าว่าง</div>
              <a href="index.html" style="color: var(--blue); margin-top: 8px; display: block;">
                เลือกซื้อสินค้า →
              </a>
            </div>
          `;
          return;
        }

        container.innerHTML = cartDetails.map(item => this.renderCartItem(item)).join('');
        this.attachItemEvents(container);
      });

      CartBadge.update();
    },

    renderCartItem(item) {
      const { product, qty, subtotal } = item;
      return `
        <div class="cart-item" data-item-id="${product.id}">
          <img src="${product.img}" alt="${product.title}"
               onerror="this.src='https://via.placeholder.com/64x48?text=No+Image'">
          <div class="meta">
            <div class="item-title">${product.title}</div>
            <div class="item-price">
              ${UIHelpers.formatPrice(product.price)} x 
              <input type="number" min="1" value="${qty}" 
                     data-action="change-qty" data-id="${product.id}">
            </div>
          </div>
          <div class="item-subtotal">${UIHelpers.formatPrice(subtotal)}</div>
          <button class="remove-btn" data-action="remove" data-id="${product.id}">✕</button>
        </div>
      `;
    },

    attachItemEvents(container) {
      container.querySelectorAll('[data-action="change-qty"]').forEach(input => {
        input.addEventListener('change', (e) => {
          const id = e.target.dataset.id;
          const qty = parseInt(e.target.value) || 1;
          Cart.updateQuantity(id, qty);
          this.renderItems();
        });
      });

      container.querySelectorAll('[data-action="remove"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.dataset.id;
          Cart.removeItem(id);
          this.renderItems();
        });
      });
    },

    checkout() {
      if (Cart.isEmpty()) {
        alert('ตะกร้าว่าง');
        return;
      }

      const url = Cart.getCheckoutLineUrl();
      if (url) {
        window.open(url, '_blank');
      }
    },

    clearCart() {
      if (confirm('ต้องการล้างตะกร้าหรือไม่?')) {
        Cart.clear();
        this.renderItems();
      }
    },

    init() {
      ['cart-toggle', 'cart-toggle-2'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', () => this.toggle());
      });

      ['cart-close', 'cart-close-2'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', () => this.close());
      });

      ['checkout-btn', 'checkout-btn-2'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', () => this.checkout());
      });

      ['clear-cart', 'clear-cart-2'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', () => this.clearCart());
      });

      Cart.subscribe(() => CartBadge.update());
      CartBadge.update();
    }
  };

  // ============================================================
  // INJECT ADDITIONAL STYLES
  // ============================================================
  function injectStyles() {
    if (document.getElementById('feiyi-extra-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'feiyi-extra-styles';
    style.textContent = `
      .toast-notification {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%) translateY(100px);
        background: #1b263b;
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        z-index: 10000;
        opacity: 0;
        transition: all 0.3s ease;
      }
      .toast-notification.show {
        transform: translateX(-50%) translateY(0);
        opacity: 1;
      }
      .empty-cart {
        padding: 24px;
        text-align: center;
        color: #7b8aa2;
      }
      .specs-box {
        background: #f6f8fb;
        padding: 12px;
        border-radius: 8px;
        margin: 12px 0;
      }
      .specs-box h4 {
        margin-bottom: 8px;
        color: var(--dark);
      }
      .specs-box ul {
        list-style: none;
        font-size: 14px;
      }
      .specs-box li {
        padding: 4px 0;
        color: var(--muted);
      }
      .category-tag {
        display: inline-block;
        background: var(--blue);
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        margin-bottom: 8px;
      }
      .stock-info {
        margin: 12px 0;
        font-size: 14px;
        color: #28a745;
      }
      .detail-actions {
        display: flex;
        gap: 10px;
        margin-top: 16px;
        flex-wrap: wrap;
      }
      .item-title {
        font-weight: 700;
      }
      .item-price {
        font-size: 13px;
        color: #7b8aa2;
      }
      .item-subtotal {
        margin-left: auto;
        font-weight: 800;
      }
      .close-btn {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        color: #7b8aa2;
      }
      .close-btn:hover {
        color: #1b263b;
      }
      .remove-btn {
        background: #ff4444;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 4px 8px;
        cursor: pointer;
        font-size: 12px;
      }
      .remove-btn:hover {
        background: #cc0000;
      }
    `;
    document.head.appendChild(style);
  }

  // ============================================================
  // APP INITIALIZATION
  // ============================================================
  function initApp() {
    console.log(`🛠️ ${CONFIG.STORE_NAME} - Initializing...`);

    injectStyles();

    const isProductPage = window.location.pathname.includes('product.html');
    const hasProductDetail = document.getElementById('product-detail');
    const hasProductGrid = document.getElementById('product-grid');

    if (isProductPage || hasProductDetail) {
      ProductDetail.render('product-detail');
    }

    if (hasProductGrid) {
      ProductGrid.render('product-grid');
    }

    CartPanel.init();
    CartBadge.update();

    console.log(`✅ ${CONFIG.STORE_NAME} - Ready!`);
  }

  // ============================================================
  // EXPOSE API (optional - for debugging)
  // ============================================================
  window.FeiyiApp = {
    cart: Cart,
    products: ProductService,
    ui: {
      openCart: () => CartPanel.open(),
      closeCart: () => CartPanel.close(),
      updateBadge: () => CartBadge.update()
    }
  };

  // Run when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }

})();
