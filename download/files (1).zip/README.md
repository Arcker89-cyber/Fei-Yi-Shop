# Fei Yi Shop v2 — Modern Blue + Kanit Font

## 🎨 ธีมที่ใช้
- **สี**: Modern Blue (น้ำเงิน #0057A0 + เหลือง #FFCC00)
- **ฟอนต์**: Kanit (Google Fonts)
- **สไตล์**: สะอาด ทันสมัย เหมาะกับร้านเครื่องมือช่าง

---

## 📁 โครงสร้างไฟล์

```
feiyi-shop-v2/
├── index.html       # หน้าหลัก
├── product.html     # หน้ารายละเอียดสินค้า
├── script.js        # JavaScript (รวม config, data, cart, ui)
└── css/
    └── style.css    # Styles + ธีม Modern Blue + Kanit
```

---

## ✨ สิ่งที่ปรับปรุงใหม่

### 🎨 Design
- ใช้ฟอนต์ **Kanit** ทั้งเว็บ (ดูแข็งแรง เหมาะกับงานช่าง)
- เพิ่ม **Gradient backgrounds** ให้ header, buttons
- ปรับ **Shadow effects** ให้ดูลึกขึ้น
- เพิ่ม **Hover animations** ที่ smooth
- ปรับ **Border radius** ให้โค้งมนขึ้น
- เพิ่ม **Color variables** ง่ายต่อการปรับแต่ง

### 📱 Responsive
- ปรับปรุง layout สำหรับมือถือ
- Product grid ใช้ CSS Grid แทน Flexbox
- Cart panel แสดงด้านล่างบนมือถือ

### 🔧 CSS Variables
```css
:root {
  --blue: #0057A0;        /* สีหลัก */
  --blue-dark: #003d73;   /* สีหลักเข้ม */
  --yellow: #FFCC00;      /* สีเน้น */
  --dark: #102030;        /* พื้นหลังเข้ม */
  --muted: #6b7a8f;       /* สีข้อความรอง */
}
```

---

## 🚀 วิธีใช้งาน

1. วางไฟล์ทั้งหมดในโฟลเดอร์เดียวกัน
2. รันด้วย Live Server หรือ web server ใดก็ได้
3. เปิด `index.html`

---

## 🎨 ปรับแต่งสี

แก้ไขใน `css/style.css` ที่ส่วน `:root`:

```css
:root {
  --blue: #your-color;      /* เปลี่ยนสีหลัก */
  --yellow: #your-accent;   /* เปลี่ยนสีเน้น */
}
```

---

## 🔤 เปลี่ยนฟอนต์

1. เลือกฟอนต์จาก [Google Fonts](https://fonts.google.com)
2. แก้ไข `@import` ใน `style.css` บรรทัดแรก
3. แก้ไข `font-family` ใน `* { ... }`

---

## 📋 TODO (ไอเดียพัฒนาต่อ)

- [ ] เพิ่มระบบค้นหาสินค้า
- [ ] เพิ่ม filter ตามหมวดหมู่
- [ ] เพิ่ม image gallery
- [ ] เพิ่ม dark mode toggle
- [ ] เชื่อมต่อ Backend API
